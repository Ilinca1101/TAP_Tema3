﻿using Lab4Web.Services.Lambda;
using Microsoft.AspNetCore.Mvc;

namespace Lab4Web.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestLambdaController : ControllerBase
    {
        private readonly ILambdaService _lambdaService;

        public TestLambdaController(ILambdaService lambdaService)
        {
            _lambdaService = lambdaService;
        }
        //2. a) vi. Tuple ca parametru;
        [HttpGet("test-1")]
        public string Get(int value)
        {
            var tupleValue = _lambdaService.Test1(value);
            return $"{tupleValue.Item1} / {tupleValue.Item2} / {tupleValue.Item3}";
        }

        [HttpGet("test-2")]
        public string Test2(string value)
        {
            return _lambdaService.Test2(value) ? "Number" : "Not number";
        }

        [HttpGet("test-3")]// 2. b) context asynchronous
        public string Test3(string value)
        {
            var result = _lambdaService.Test3Async(value).Result;
            return result;
        }

        [HttpGet("test-4")]  // 2. a) i. Fără parametri
        public IActionResult LambdaNoParams()
        {
            Action lambda = () => {
                Console.WriteLine("Expresie lambda fără parametri.");
            };
            lambda();

            return Ok("Expresia lambda fără parametri a fost apelată.");
        }

        [HttpGet("test-5")] //2. a) ii. Un param
        public IActionResult LambdaOneParam(int value)
        {
            Func<double, double> cube = x =>
                x*x*x;
            

            return Ok(cube(value));
        }

        [HttpGet("test-6")] //2. a) iii. Doi param
        public IActionResult LambdaTwoParams(int value1, int value2)
        {
            Func<int, int, int> suma = (x, y) => {
                return x + y;
            };

            return Ok($"Suma este: {suma(value1, value2)}");
        }

        [HttpGet("test-7")] //2. a) iv. Parametri neutilizati în expresie

        public IActionResult LambdaUnusedParams(int value1, int value2)
        {
            Func<int, int, int> constant = (_, _) => 56;
                
            return Ok(constant(value1, value2));
        }

        [HttpGet("test-8")] //2. a)v. Parametri cu valori default

        public IActionResult LambdaDefaultParams(int value1 = 1, int value2 = 2)
        {
            Func<int, int, string> lambda = (int x = 1, int y = 2) => 
            {
                return $"Parametri cu valori default: {x}, {y}";
            };

            return Ok(lambda(value1, value2));
        }



    }
}
