using Lab4Web.Services.Linq;
using Microsoft.AspNetCore.Mvc;

namespace Lab4Web.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestLinqController : ControllerBase
    {
        private readonly ILinqService _linqService;

        public TestLinqController(ILinqService linqService)
        {
            _linqService = linqService;
        }

        [HttpGet("test-1")]
        public int Get(int price)
        {
            return _linqService.Test1(price);
        }

        [HttpGet("test-2")]
        public List<Book> Test2()
        {
            return _linqService.Test2();
        }

        [HttpGet("test-3")]
        public List<string> Test3()
        {
            return _linqService.Test3();
        }

        [HttpGet("test-4")]
        public int Test4()
        {
            return _linqService.Test4();
        }


        [HttpGet("test-5")]
        public List<string> Test5()
        {
            return _linqService.Test5();
        }



    }    


  }

