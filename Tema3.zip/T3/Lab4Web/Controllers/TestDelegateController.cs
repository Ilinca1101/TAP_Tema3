﻿using Lab4Web.Services.Delegate;
using Microsoft.AspNetCore.Mvc;

namespace Lab4Web.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestDelegateController : ControllerBase
    {
        private readonly IDelegateService _delegateService;

        public TestDelegateController(IDelegateService delegateService)
        {
            _delegateService = delegateService;
        }
        // delegate pentru a apela mai multe metode consecutive
        public delegate void MultipleMethodsDelegate(string message);// 1. c)
        // 1. a)
        [HttpGet("test-1")]
        public string Test1(string name)
        {
            var callback = _delegateService.Hello;

            return _delegateService.Introduction(name, callback);
        }
        //1. b) în funcție de o condiție impusă- daca selectam true=> Hello,
        // daca selectam false=> Bye
        [HttpGet("test-2")]
        public string Test2(string name, bool welcome)
        {
            var callback1 = _delegateService.Hello;
            var callback2 = (string firstname, string lastname) => $"Bye, {firstname} {lastname}";

            var callback = welcome ? callback1 : callback2;

            return _delegateService.Introduction(name, callback);
        }

        [HttpGet("test-3")] //1. c)
        public IActionResult Test3(string message)
        {
            // named-method initializare
            MultipleMethodsDelegate multipleMethodsDelegate = FirstMethod;

            // Adăugarea unei metode prin intermediul unei expresii lambda
            multipleMethodsDelegate += (string msg) => {
                Console.WriteLine($"mesaj dintr-o expresie lambda: {msg}");
            };

            // Apelarea delegate-ului care va executa ambele metode
            multipleMethodsDelegate(message);

            return Ok("Metodele consecutive au fost apelate.");
           
        }

        private void FirstMethod(string message)
        {
            Console.WriteLine($"Acesta este un mesaj din metoda numită: {message}");
        }


    }
}
