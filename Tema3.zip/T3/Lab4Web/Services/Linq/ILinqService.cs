﻿namespace Lab4Web.Services.Linq
{
    public interface ILinqService
    {
        int Test1(int value);
        List<Book> Test2();
        List<string> Test3();
        public int Test4();

        public List<string> Test5();
    }
}
