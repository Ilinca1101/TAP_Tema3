﻿namespace Lab4Web.Services.Linq
{
    public class Book
    {
        //3. a) clasa la alegere cu 5 proprietati 
        public Book(string title, string author, int year, string genre, double price)
        {
            Title = title;
            Author = author;
            Year = year;
            Genre = genre;
            Price = price;
        }

        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public string Genre { get; set; }
        public double Price { get; set; }
    }

    public class LinqService : ILinqService //3. b)
    {
        public static List<Book> Books = new List<Book>() //lista cu obiecte specifice clasei 
        {
            new Book("Book1", "Author1", 2000, "Fantasy", 20.5),
            new Book("Book2", "Author2", 2005, "Mystery", 15.0),
            new Book("Book3", "Author3", 2010, "Science Fiction", 18.0),
            new Book("Book4", "Author4", 2015, "Thriller", 22.0),
            new Book("Book5", "Author5", 2020, "Romance", 25.0),
            new Book("Book6", "Author6", 2012, "Horror", 17.0),
            new Book("Book7", "Author7", 2008, "Historical Fiction", 19.0),
            new Book("Book8", "Author8", 2017, "Biography", 21.0),
            new Book("Book9", "Author9", 2019, "Non-Fiction", 16.0),
            new Book("Book10", "Author10", 2011, "Drama", 23.0)
        };

        public int Test1(int value) 
        {
            // Query-expression
            var query1 = from book in Books
                         where book.Price >= value
                         select book;

            // Method-expression book
            var query2 = Books.Where(book => book.Price >= value);

            return query1.Count();
        }

        public List<Book> Test2() //3. c) i.
        {
            // return o listă de obiecte după aplicarea unei clauze where
            var query = LinqService.Books.Where(book => book.Price > 20).ToList();

            return query;
        }

        public List<string> Test3() //3. c) ii.
        {
            // return o listă de stringuri, doar cu valoarea unei proprietăți
            var query = LinqService.Books.Select(book => book.Title).ToList();
            return query;
            
        }

        public int Test4()//3. c) iii.
        {
            //return numărul de elemente din lista primită
            var query = LinqService.Books.Count();

            return query;
        }

        public List<string> Test5() //3. d)
        {
            // d) i. Where
            var query1 = LinqService.Books.Where(book => book.Price < 20).ToList();
            //cartile ce au pretul mai mic de 20 sunt stocate intr-o lista
            // d) ii. Join
            var authors = new List<Author>//pentru a combina lista de cărți cu lista de autori
            {
                new Author { Name = "Author1", Country = "Country1" },
                new Author { Name = "Author2", Country = "Country2" },
                new Author { Name = "Author3", Country = "Country3" }
            };

            var query2 = LinqService.Books.Join(authors,
                                                   book => book.Author,//cheia de legare din lista de cărți
                                                   author => author.Name,//cheia de legare din lista de autori
                                                   (book, author) => new { book.Title, author.Country })
                                              .Select(result => $"{result.Title} - {result.Country}")
                                              .ToList();
            //Obiectul conține titlul cărții și țara autorului
            //rezultatul este o listă de stringuri-> titlul cărții cu țara autorului

            // d) iii. Group
            var query3 = LinqService.Books.GroupBy(book => book.Genre) //grupez cartile dupa gen
                                              .Select(group => $"{group.Key} - {group.Count()}")
                                              .ToList();//key=>genul+lista de carti din acel gen
            //Select pentru a transforma fiecare grup într-un string format
            //din gen și numărul de cărți din acel gen(grup)
            var resultList = new List<string>();
            resultList.AddRange(query1.Select(book => book.Title));
            resultList.AddRange(query2);
            resultList.AddRange(query3);

            return resultList;
        }
    }

    public class Author //pentru folosirea metodei Join
    {
        public string Name { get; set; }
        public string Country { get; set; }
    }
}


